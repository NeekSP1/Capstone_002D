from django.shortcuts import render, redirect
from django.contrib import messages
from django.contrib.auth.hashers import check_password, make_password
from Gotti.models import Cliente
from django.shortcuts import get_object_or_404


def index(request):
    return render(request, 'Gotti/styleblog/index.html')

def contacto(request):
    return render(request, 'Gotti/styleblog/contacto.html')

def iniciarCliente(request):
    return render(request, 'Gotti/styleblog/iniciarCliente.html')

def iniciarColaborador(request):
    return render(request, 'Gotti/styleblog/iniciarColaborador.html')

def iniciarSesion(request):
    return render(request, 'Gotti/styleblog/iniciarSesion.html')

def inicioCliente(request):
    return render(request, 'Gotti/styleblog/inicioCliente.html')

def inicioColaborador(request):
    return render(request, 'Gotti/styleblog/inicioColaborador.html')

def nosotros(request):
    return render(request, 'Gotti/styleblog/nosotros.html')

def perfilCliente(request):
    return render(request, 'Gotti/styleblog/perfilCliente.html')



def perfilColaborador(request):
    return render(request, 'Gotti/styleblog/perfilColaborador.html')

def registrarse(request):
    return render(request, 'Gotti/styleblog/registrarse.html')




def indexBarbero(request):
    return render(request, 'Gotti/VistaBarbero/index.html')

def carritobarbero(request):
    return render(request, 'Gotti/VistaCliente/carritobarbero.html')

def contactoact(request):
    return render(request, 'Gotti/VistaCliente/contactoact.html')

def contactobarbero(request):
    return render(request, 'Gotti/VistaCliente/contactobarbero.html')

def datosbarbero(request):
    return render(request, 'Gotti/VistaCliente/datosbarbero.html')

def horaeliminada(request):
    return render(request, 'Gotti/VistaCliente/horaeliminada.html')

def horareserva(request):
    return render(request, 'Gotti/VistaCliente/horareserva.html')

def productoact(request):
    return render(request, 'Gotti/VistaCliente/productoact.html')

def productoact2(request):
    return render(request, 'Gotti/VistaCliente/productoact2.html')

def productoact3(request):
    return render(request, 'Gotti/VistaCliente/productoact3.html')

def productos(request):
    return render(request, 'Gotti/VistaCliente/productos.html')

def servicioact(request):
    return render(request, 'Gotti/VistaCliente/servicioact.html')

def servicioact2(request):
    return render(request, 'Gotti/VistaCliente/servicioact2.html')

def servicioact3(request):
    return render(request, 'Gotti/VistaCliente/servicioact3.html')

def servicios(request):
    return render(request, 'Gotti/VistaCliente/servicios.html')

def verhora(request):
    return render(request, 'Gotti/VistaCliente/verhora.html')




def indexCliente(request):
    return render(request, 'Gotti/VistaCliente/index.html')

def carritoCliente(request):
    return render(request, 'Gotti/VistaCliente/carrito.html')

def contactoCliente(request):
    return render(request, 'Gotti/VistaCliente/contacto.html')

def datosCliente(request):
    return render(request, 'Gotti/VistaCliente/datos.html')

def nosotrosCliente(request):
    return render(request, 'Gotti/VistaCliente/nosotros.html')

def productosCliente(request):
    return render(request, 'Gotti/VistaCliente/productos.html')

def servicioInfCliente(request):
    return render(request, 'Gotti/VistaCliente/servicioinf.html')

def servicioInfCliente2(request):
    return render(request, 'Gotti/VistaCliente/servicioinf2.html')

def servicioInfCliente3(request):
    return render(request, 'Gotti/VistaCliente/servicioinf3.html')

def serviciosCliente(request):
    return render(request, 'Gotti/VistaCliente/servicios.html')



# Registro de cliente
def registrarse(request):
    if request.method == 'POST':
        nombre = request.POST.get('nombre')
        apellido = request.POST.get('apellido')
        email = request.POST.get('email')
        password = request.POST.get('password')

        # Cifrar la contraseña antes de guardar
        cliente = Cliente(
            nombre=nombre,
            apellido=apellido,
            correoElectronico=email,
            contraseña=make_password(password)  # Cifrar contraseña
        )
        cliente.save()

        messages.success(request, 'Cuenta creada con éxito. Ahora puedes iniciar sesión.')
        return redirect('iniciarSesion')  # Redirigir a la página de inicio de sesión

    return render(request, 'Gotti/styleblog/registrarse.html')


# Inicio de sesión para clientes
def iniciar_sesion_cliente(request):
    if request.method == 'POST':
        email = request.POST.get('email')
        password = request.POST.get('password')

        try:
            # Verificar si existe el cliente con ese correo
            cliente = Cliente.objects.get(correoElectronico=email)
        except Cliente.DoesNotExist:
            messages.error(request, 'Cliente no encontrado.')
            return redirect('iniciarSesion')

        # Verificar la contraseña cifrada
        if check_password(password, cliente.contraseña):
            # Iniciar sesión (no usando el login de Django directamente, pero podrías implementarlo)
            request.session['cliente_id'] = cliente.idCliente
            messages.success(request, 'Sesión iniciada correctamente.')
            return redirect('inicioCliente')  # Redirigir al dashboard del cliente
        else:
            messages.error(request, 'Contraseña incorrecta.')

    return render(request, 'Gotti/styleblog/iniciarCliente.html')

def perfil_Cliente(request):
    # Asumiendo que el cliente está autenticado
    cliente = get_object_or_404(Cliente, correoElectronico=request.user.email)

    if request.method == 'POST':
        # Obtener los datos del formulario
        nombre = request.POST.get('nombre')
        apellido = request.POST.get('apellido')
        email = request.POST.get('email')
        password = request.POST.get('password')

        # Actualizar los campos del cliente
        cliente.nombre = nombre
        cliente.apellido = apellido
        cliente.correoElectronico = email
        if password:  # Solo actualizar si el usuario ingresó una nueva contraseña
            cliente.contraseña = password

        # Guardar los cambios
        cliente.save()
        messages.success(request, 'Perfil actualizado con éxito.')
        return redirect('perfilCliente')